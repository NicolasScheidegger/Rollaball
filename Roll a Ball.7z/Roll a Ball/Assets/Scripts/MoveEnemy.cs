﻿using UnityEngine;
using System.Collections;

public class MoveEnemy : MonoBehaviour {
   public float x =0.05f;
   public float y =0;
   public float z =0;
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
        Vector3 move = new Vector3(x,y,z);
        //Vector3 remove = new Vector3(-0.03f, 0f, 0f);
        this.transform.Translate(move);
        //this.transform.Translate(remove);
    }
    void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.CompareTag("Wall"))
        {
            x = -x;

        }
    }
}
