﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using UnityEngine.SceneManagement;

public class PlayerController : MonoBehaviour {
	
	public float speed;
    public float jumpSpeed;
	private Rigidbody rb;
    public GameObject pickup;
    public GameObject enemy;
    public Observer observer;
    public Text countText;
    public int count;
    public Text winText;
    public Text chronometer;
    public Text toWin;
    public int countPickup = 12;
    public bool help;
	void Start(){
        Debug.Log("Fonction start");
		rb = GetComponent<Rigidbody>();
        count = 0;
        SetcountText();
        winText.text = "";

    }
	void FixedUpdate()
    {
        
		float moveHorizontal = Input.GetAxis ("Horizontal");
		float moveVertical = Input.GetAxis ("Vertical");
        if (Input.GetKeyDown("space"))
        {
                Vector3 jump = new Vector3(moveHorizontal, 10, moveVertical);
                rb.AddForce(jump * jumpSpeed);

            
        }

		Vector3 movement = new Vector3 (moveHorizontal, 0.0f, moveVertical);

		rb.AddForce (movement * speed);
	}


    // Destroy everything that enters the trigger

    void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.CompareTag("Pick Up"))
        {
            other.gameObject.SetActive(false);
            count = count + 1;
            SetcountText();
        }
        if (other.gameObject.CompareTag("Balle")) {
            enemy.SetActive(false);
            pickup.SetActive(false);
            winText.text= "You lose! press 'R' to retry";
            observer.countDeath++;
        }

    }

    void Update()
    {
        SetcountText();
        if (Input.GetKeyDown("r"))
        {
            SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
        }

    }


    void SetcountText()
    {
        
       toWin.text = (countPickup-observer.countDeath).ToString();
        chronometer.text = observer.minutes.ToString()+" min "+observer.secondes.ToString()+" sec";
        countText.text = "Count: " + count.ToString();
        if (count >= (countPickup-observer.countDeath) && help == false)
        {
            winText.text = "Si si ma gueule!!!!";
        }
        if (help == true)
        {
            winText.text = "You're welcome!";
        }
    }

           
}
