﻿using UnityEngine;
using System.Collections;


public class Observer : MonoBehaviour {
    private static Observer instance = null;
    public PlayerController player;
    public float time;
    public int secondes;
    public int minutes;
    public bool help;

    public static Observer Instance
    {
        get
        {
            return instance;
        }
    }

    private void Awake()
    {
        if (instance != null && instance != this)
        {
            Debug.Log("Instance precedente detruite");
            Destroy(this.gameObject);

        }

        instance = this;
        Debug.Log("Singleton update");
        DontDestroyOnLoad(this.gameObject);
    }

    public int countDeath = 0;
	// Use this for initialization
	void Start () {
        time = 0;
        secondes = 0;
        minutes = 0;


	}
	
	// Update is called once per frame
	void Update () {
        time = Time.time;
        secondes = (int)time % 60;
        minutes = (int)time / 60;
        Chrono();
    }

    void Chrono()
    {
        if (minutes >= 1)
        {
           help = true;
           player.pickup.SetActive(false);
           player.count = 12;
        }
    }
}
